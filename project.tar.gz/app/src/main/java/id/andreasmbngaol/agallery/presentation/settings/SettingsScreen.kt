package id.andreasmbngaol.agallery.presentation.settings

import android.os.Build
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import id.andreasmbngaol.agallery.core.ui.isFrostedSupported
import id.andreasmbngaol.agallery.core.ui.resolveEdgeEffectMode
import id.andreasmbngaol.agallery.domain.model.EdgeEffectMode
import org.koin.androidx.compose.koinViewModel

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = koinViewModel(),
) {
    val settings by viewModel.settings.collectAsState()
    SettingsContent(
        chosenMode = settings.edgeEffectMode,
        onSelectMode = viewModel::onSelectEdgeEffect,
    )
}

@Composable
private fun SettingsContent(
    chosenMode: EdgeEffectMode?,
    onSelectMode: (EdgeEffectMode) -> Unit,
) {
    val defaultMode = remember { resolveEdgeEffectMode(null, Build.VERSION.SDK_INT) }
    val shownSelection = chosenMode ?: defaultMode
    val frostedSupported = isFrostedSupported()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(text = "Setelan", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        Text(text = "Efek tepi layar", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(2.dp))
        Text(
            text = "Efek di area status bar & navigation bar saat foto di-scroll ke belakangnya.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))

        Column(Modifier.selectableGroup()) {
            EdgeEffectOption(
                title = "Frosted (blur)",
                subtitle = if (frostedSupported) {
                    "Kaca buram di belakang system bar"
                } else {
                    "Perlu Android 12+ — di perangkat ini otomatis jadi Gradient"
                },
                selected = shownSelection == EdgeEffectMode.FROSTED,
                onClick = { onSelectMode(EdgeEffectMode.FROSTED) },
            )
            EdgeEffectOption(
                title = "Gradient gelap",
                subtitle = "Gradasi gelap tipis, ringan untuk semua perangkat",
                selected = shownSelection == EdgeEffectMode.GRADIENT,
                onClick = { onSelectMode(EdgeEffectMode.GRADIENT) },
            )
            EdgeEffectOption(
                title = "Mati",
                subtitle = "Tanpa efek apa pun di tepi layar",
                selected = shownSelection == EdgeEffectMode.OFF,
                onClick = { onSelectMode(EdgeEffectMode.OFF) },
            )
        }
    }
}

@Composable
private fun EdgeEffectOption(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

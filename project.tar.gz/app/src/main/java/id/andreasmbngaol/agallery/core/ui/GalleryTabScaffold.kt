package id.andreasmbngaol.agallery.core.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Regular
import com.adamglin.phosphoricons.regular.Gear
import com.adamglin.phosphoricons.regular.SortAscending
import com.adamglin.phosphoricons.regular.SortDescending
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder

/**
 * Dua tab utama root screen di AGallery.
 */
enum class GalleryTab { Gallery, Albums }

/**
 * Tinggi total footprint bar mengambang dari BAWAH area content, di luar
 * `WindowInsets.navigationBars`. Nilai ini dipakai oleh screen di dalam
 * scaffold untuk menambah `contentPadding.bottom` grid mereka supaya item
 * terakhir tidak ketutup bar.
 *
 * Perhitungan: 12dp (padding atas bar) + 52dp (tinggi tombol) + 12dp
 * (padding bawah bar sebelum nav bar) = 76dp.
 */
val FloatingTabBarHeight = 76.dp

private val FloatingButtonSize = 52.dp

/**
 * Scaffold sederhana untuk screen root (Gallery/Albums) yang menampilkan
 * bar mengambang di bawah:
 *
 * ```
 * ┌────────────────────────────────┐
 * │                                │
 * │           content()            │
 * │                                │
 * │  (⚙)  [ Gallery | Albums ]  (⇅) │  <- floating bar (fill lebar layar)
 * │     (nav bar area)             │
 * └────────────────────────────────┘
 * ```
 *
 * ## Layout
 *
 * Bar pakai `Row.fillMaxWidth()` + `Arrangement.SpaceBetween` supaya:
 * - Tombol Settings menempel ke edge kiri (padding 16dp).
 * - Segmented pill di tengah, ukuran natural (tidak stretch).
 * - Tombol Sort menempel ke edge kanan (padding 16dp).
 *
 * Karena `SpaceBetween` men-distribusi RUANG SISA, tombol-tombolnya sendiri
 * tetap ukuran natural (52dp bulat & pill sepanjang label). Yang membesar
 * hanya jarak antara mereka.
 */
@Composable
fun GalleryTabScaffold(
    selectedTab: GalleryTab,
    onSelectTab: (GalleryTab) -> Unit,
    onOpenSettings: () -> Unit,
    sortOrder: GallerySortOrder,
    onToggleSort: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Box(modifier = modifier.fillMaxSize()) {
        content()
        FloatingTabBar(
            selectedTab = selectedTab,
            onSelectTab = onSelectTab,
            onOpenSettings = onOpenSettings,
            sortOrder = sortOrder,
            onToggleSort = onToggleSort,
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

@Composable
private fun FloatingTabBar(
    selectedTab: GalleryTab,
    onSelectTab: (GalleryTab) -> Unit,
    onOpenSettings: () -> Unit,
    sortOrder: GallerySortOrder,
    onToggleSort: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularFloatingButton(
            onClick = onOpenSettings,
            contentDescription = "Setelan",
        ) {
            Icon(
                imageVector = PhosphorIcons.Regular.Gear,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
            )
        }

        SegmentedPill(
            selectedTab = selectedTab,
            onSelectTab = onSelectTab,
        )

        CircularFloatingButton(
            onClick = onToggleSort,
            contentDescription = "Ubah urutan",
        ) {
            // AnimatedContent supaya icon fade+slide saat berganti order.
            // Arah slide dibalik antar transisi supaya kesan panah
            // "membalik": DESC → ASC panah baru masuk dari atas, panah lama
            // turun ke bawah; ASC → DESC kebalikannya.
            //
            // Catatan API: `using` adalah `infix fun ContentTransform.using(
            // SizeTransform)`. Karena presedens `.using(...)` lebih tinggi
            // dari infix `togetherWith`, ekspresi `A togetherWith B.using(x)`
            // sebetulnya di-parse sebagai `A togetherWith (B.using(x))`, dan
            // `.using()` diminta dari ExitTransition — kompiler akan bilang
            // "unresolved reference: using". Jadi kita bangun langsung via
            // konstruktor `ContentTransform(...)`, tidak perlu `togetherWith`
            // maupun `using` di ekspresi ini.
            AnimatedContent(
                targetState = sortOrder,
                transitionSpec = {
                    val goingToAsc = targetState == GallerySortOrder.DateAsc
                    ContentTransform(
                        targetContentEnter = fadeIn(tween(220)) +
                            slideInVertically(tween(260)) { h ->
                                if (goingToAsc) -h / 2 else h / 2
                            },
                        initialContentExit = fadeOut(tween(160)) +
                            slideOutVertically(tween(200)) { h ->
                                if (goingToAsc) h / 2 else -h / 2
                            },
                        sizeTransform = SizeTransform(clip = false),
                    )
                },
                label = "sort-icon",
            ) { order ->
                Icon(
                    imageVector = when (order) {
                        GallerySortOrder.DateDesc -> PhosphorIcons.Regular.SortDescending
                        GallerySortOrder.DateAsc -> PhosphorIcons.Regular.SortAscending
                    },
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}

/**
 * Container circular tonal + shadow. Alpha 0.85 supaya konten grid di
 * belakangnya samar-samar terlihat (efek "floating" á la iOS).
 *
 * Ukuran tetap [FloatingButtonSize] — tidak stretch meski parent pakai
 * SpaceBetween.
 */
@Composable
private fun CircularFloatingButton(
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.85f),
        contentColor = MaterialTheme.colorScheme.onSurface,
        shadowElevation = 6.dp,
        modifier = modifier.size(FloatingButtonSize),
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            content()
        }
    }
}

@Composable
private fun SegmentedPill(
    selectedTab: GalleryTab,
    onSelectTab: (GalleryTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.85f),
        contentColor = MaterialTheme.colorScheme.onSurface,
        shadowElevation = 6.dp,
        modifier = modifier.height(FloatingButtonSize),
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PillSegment(
                label = "Gallery",
                selected = selectedTab == GalleryTab.Gallery,
                onClick = { onSelectTab(GalleryTab.Gallery) },
            )
            Spacer(Modifier.width(2.dp))
            PillSegment(
                label = "Albums",
                selected = selectedTab == GalleryTab.Albums,
                onClick = { onSelectTab(GalleryTab.Albums) },
            )
        }
    }
}

@Composable
private fun PillSegment(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bg by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.surface
        } else {
            Color.Transparent
        },
        animationSpec = tween(180),
        label = "pill-bg",
    )
    val fg by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.onSurface
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = tween(180),
        label = "pill-fg",
    )
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = fg,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            ),
        )
    }
}

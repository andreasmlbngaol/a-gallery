package id.andreasmbngaol.agallery.data.local.mediastore

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder
import id.andreasmbngaol.agallery.domain.model.MediaItem
import id.andreasmbngaol.agallery.domain.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Baca media (foto & video) dari MediaStore lewat ContentResolver.
 *
 * ## Kenapa tabel Files (bukan Images/Video terpisah)?
 *
 * Kita query `MediaStore.Files.getContentUri(...)` dengan filter
 * `MEDIA_TYPE IN (IMAGE, VIDEO)`. Alasan:
 *
 * - Foto & video muncul di satu list terurut (kayak Google Photos / iOS Photos).
 * - Cukup satu round-trip cursor, gak perlu merge dua flow.
 *
 * URI per-item tetap dibangun dari koleksi per-tipe (`Images.Media` /
 * `Video.Media`) supaya Coil bisa milih decoder yang tepat.
 *
 * ## Sort + pagination
 *
 * Kita pakai `ContentResolver.query(uri, projection, queryArgs, signal)`
 * dengan `Bundle` (API 26+; project ini minSdk=29). Ini cara resmi buat
 * pass `QUERY_ARG_LIMIT` + `QUERY_ARG_OFFSET` — lebih bersih dan aman
 * daripada nyempilin `LIMIT x OFFSET y` ke string sortOrder (yang di API
 * baru bisa diblok).
 *
 * Tie-break pakai `_ID` biar urutan stabil kalau ada dua foto punya
 * `DATE_ADDED` sama (misal dari import massal).
 */
class MediaStoreDataSource(
    private val context: Context,
) {

    private val contentResolver: ContentResolver get() = context.contentResolver

    private val collectionUri: Uri =
        MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.DISPLAY_NAME,
        MediaStore.Files.FileColumns.MIME_TYPE,
        MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.Files.FileColumns.DATE_ADDED,
        MediaStore.Files.FileColumns.BUCKET_ID,
        MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
    )

    suspend fun queryMedia(
        limit: Int,
        offset: Int,
        sortOrder: GallerySortOrder,
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val selectionArgs = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        val direction = when (sortOrder) {
            GallerySortOrder.DateDesc -> "DESC"
            GallerySortOrder.DateAsc -> "ASC"
        }
        val sortSql =
            "${MediaStore.Files.FileColumns.DATE_ADDED} $direction, " +
                "${MediaStore.Files.FileColumns._ID} $direction"

        val queryArgs = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, selectionArgs)
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sortSql)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
            putInt(ContentResolver.QUERY_ARG_OFFSET, offset)
        }

        contentResolver.query(collectionUri, projection, queryArgs, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val mimeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val typeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
            val bucketIdCol = c.getColumnIndex(MediaStore.Files.FileColumns.BUCKET_ID)
            val bucketNameCol = c.getColumnIndex(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME)

            buildList(c.count) {
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val mediaType = c.getInt(typeCol)
                    val type = if (mediaType == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) {
                        MediaType.VIDEO
                    } else {
                        MediaType.IMAGE
                    }
                    val itemUri: Uri = ContentUris.withAppendedId(
                        when (type) {
                            MediaType.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            MediaType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        },
                        id,
                    )
                    add(
                        MediaItem(
                            id = id,
                            uri = itemUri.toString(),
                            displayName = c.getString(nameCol).orEmpty(),
                            mimeType = c.getString(mimeCol).orEmpty(),
                            type = type,
                            dateAddedEpochSeconds = c.getLong(dateCol),
                            bucketId = if (bucketIdCol >= 0) c.getLong(bucketIdCol) else 0L,
                            bucketName = if (bucketNameCol >= 0) {
                                c.getString(bucketNameCol).orEmpty()
                            } else {
                                ""
                            },
                            // TODO: merge dengan tabel Favorites di Room
                            //  (butuh join di layer repository).
                            isFavorite = false,
                        ),
                    )
                }
            }
        } ?: emptyList()
    }

    suspend fun queryAlbums(): List<MediaItem> {
        // TODO: SELECT dengan GROUP BY BUCKET_ID / BUCKET_DISPLAY_NAME +
        //  agregasi COUNT(*) & first-item URI utk cover album.
        return emptyList()
    }
}

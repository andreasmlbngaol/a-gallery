package id.andreasmbngaol.agallery.presentation.gallery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import id.andreasmbngaol.agallery.domain.model.EdgeEffectMode
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder
import id.andreasmbngaol.agallery.domain.model.MediaItem
import id.andreasmbngaol.agallery.domain.usecase.GetMediaPagingUseCase
import id.andreasmbngaol.agallery.domain.usecase.ToggleFavoriteUseCase
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

/**
 * State galeri:
 * - [sortOrder]: DESC/ASC by date. Ganti order akan re-trigger paging
 *   lewat `flatMapLatest`, PagingSource lama otomatis di-cancel.
 * - [edgeEffectMode]: mode edge scrim (frosted / gradient / off).
 */
class GalleryViewModel(
    private val getMediaPaging: GetMediaPagingUseCase,
    private val toggleFavorite: ToggleFavoriteUseCase,
) : ViewModel() {

    private val _sortOrder = MutableStateFlow(GallerySortOrder.DateDesc)
    val sortOrder: StateFlow<GallerySortOrder> = _sortOrder.asStateFlow()

    private val _edgeEffectMode = MutableStateFlow(EdgeEffectMode.FROSTED)
    val edgeEffectMode: StateFlow<EdgeEffectMode> = _edgeEffectMode.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val media: Flow<PagingData<MediaItem>> = _sortOrder
        .flatMapLatest { order -> getMediaPaging(order) }
        .cachedIn(viewModelScope)

    fun setSortOrder(order: GallerySortOrder) {
        if (_sortOrder.value != order) _sortOrder.value = order
    }

    fun toggleSortOrder() {
        _sortOrder.value = when (_sortOrder.value) {
            GallerySortOrder.DateDesc -> GallerySortOrder.DateAsc
            GallerySortOrder.DateAsc -> GallerySortOrder.DateDesc
        }
    }

    fun setEdgeEffectMode(mode: EdgeEffectMode) {
        _edgeEffectMode.value = mode
    }

    fun onToggleFavorite(mediaId: Long, isFavorite: Boolean) {
        viewModelScope.launch {
            toggleFavorite(mediaId, isFavorite)
        }
    }
}

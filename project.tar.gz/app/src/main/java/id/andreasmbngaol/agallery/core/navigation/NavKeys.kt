package id.andreasmbngaol.agallery.core.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable

/**
 * Nav3 route keys. Tiap layar = satu NavKey.
 *
 * @Serializable diperlukan supaya backstack bisa di-save/restore (selamat dari
 * process death) lewat rememberNavBackStack.
 */
sealed interface Screen : NavKey {
    @Serializable
    data object Gallery : Screen

    /**
     * [initialIndex] = posisi item saat di-tap di grid, dipakai sebagai halaman
     * awal HorizontalPager di PhotoViewer. Nilai ini bertahan lewat process
     * death karena @Serializable.
     */
    @Serializable
    data class PhotoViewer(
        val mediaId: Long,
        val initialIndex: Int,
    ) : Screen

    @Serializable
    data object Albums : Screen

    @Serializable
    data object Settings : Screen
}

package id.andreasmbngaol.agallery.presentation.gallery

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import androidx.paging.compose.collectAsLazyPagingItems
import coil3.compose.AsyncImage
import com.adamglin.PhosphorIcons
import com.adamglin.phosphoricons.Regular
import com.adamglin.phosphoricons.regular.ImageSquare
import com.adamglin.phosphoricons.regular.MagnifyingGlass
import com.adamglin.phosphoricons.regular.WarningCircle
import id.andreasmbngaol.agallery.core.permission.MediaPermissionGate
import id.andreasmbngaol.agallery.core.ui.FloatingTabBarHeight
import id.andreasmbngaol.agallery.core.ui.GalleryTab
import id.andreasmbngaol.agallery.core.ui.GalleryTabScaffold
import id.andreasmbngaol.agallery.core.ui.SystemBarScrim
import id.andreasmbngaol.agallery.core.ui.rememberEffectiveEdgeEffectMode
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder
import id.andreasmbngaol.agallery.domain.model.MediaItem
import id.andreasmbngaol.agallery.presentation.animation.sharedPhotoElement
import org.koin.androidx.compose.koinViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

// Tinggi visual TopAppBar (sedikit di atas M3 default 64dp untuk
// mengakomodasi judul 26sp SemiBold + FilledTonalIconButton 44dp).
private val GalleryTopAppBarHeight = 72.dp

// Judul default saat grid di posisi paling atas.
private const val DefaultTitle = "Gallery"

private val TitleDateFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())

private fun formatTitleDate(epochSeconds: Long): String =
    Instant.ofEpochSecond(epochSeconds)
        .atZone(ZoneId.systemDefault())
        .format(TitleDateFormatter)
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

/**
 * Layar utama galeri.
 *
 * Terima [sortOrder] & [onToggleSort] dari NavDisplay supaya state sort
 * TETAP saat pindah tab Gallery ↔ Albums. VM ikut sinkron via
 * `LaunchedEffect(sortOrder) { viewModel.setSortOrder(sortOrder) }`.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryGridScreen(
    onMediaClick: (mediaId: Long, index: Int) -> Unit,
    onSelectTab: (GalleryTab) -> Unit,
    onOpenSettings: () -> Unit,
    sortOrder: GallerySortOrder,
    onToggleSort: () -> Unit,
    onOpenSearch: () -> Unit = {},
    viewModel: GalleryViewModel = koinViewModel(),
) {
    // Sinkronkan sortOrder yang di-hoist di NavDisplay ke VM. VM akan
    // rebuild PagingSource via flatMapLatest.
    LaunchedEffect(sortOrder) {
        viewModel.setSortOrder(sortOrder)
    }

    val chosenMode by viewModel.edgeEffectMode.collectAsState()
    val effectiveMode = rememberEffectiveEdgeEffectMode(chosenMode)

    val gridState = rememberLazyGridState()
    val items = viewModel.media.collectAsLazyPagingItems()

    val topBarTitle by remember(items) {
        derivedStateOf {
            val isAtTop = gridState.firstVisibleItemIndex == 0 &&
                    gridState.firstVisibleItemScrollOffset == 0
            if (isAtTop || items.itemCount == 0) {
                DefaultTitle
            } else {
                items.peek(gridState.firstVisibleItemIndex)
                    ?.dateAddedEpochSeconds
                    ?.let(::formatTitleDate)
                    ?: DefaultTitle
            }
        }
    }

    val safeDrawingPadding = WindowInsets.safeDrawing.asPaddingValues()
    val layoutDirection = LocalLayoutDirection.current
    // Bottom = safeArea (nav bar) + tinggi floating bar. Grid tetap edge-to-
    // edge (fillMaxSize), item terakhir cukup padded supaya tidak ke-tutup
    // pill segmented bar.
    val gridContentPadding = PaddingValues(
        top = safeDrawingPadding.calculateTopPadding() + GalleryTopAppBarHeight,
        bottom = safeDrawingPadding.calculateBottomPadding() + FloatingTabBarHeight,
        start = safeDrawingPadding.calculateStartPadding(layoutDirection),
        end = safeDrawingPadding.calculateEndPadding(layoutDirection),
    )

    GalleryTabScaffold(
        selectedTab = GalleryTab.Gallery,
        onSelectTab = onSelectTab,
        onOpenSettings = onOpenSettings,
        sortOrder = sortOrder,
        onToggleSort = onToggleSort,
    ) {
        SystemBarScrim(
            mode = effectiveMode,
            topExtraHeight = GalleryTopAppBarHeight,
            topOverlay = {
                TopAppBar(
                    modifier = Modifier.align(Alignment.TopCenter),
                    title = {
                        AnimatedContent(
                            targetState = topBarTitle,
                            transitionSpec = {
                                (fadeIn(tween(180)) togetherWith fadeOut(tween(180)))
                                    .using(SizeTransform(clip = false))
                            },
                            label = "gallery-title",
                        ) { title ->
                            Text(
                                text = title,
                                style = LocalTextStyle.current.copy(
                                    fontSize = 26.sp,
                                    lineHeight = 32.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.35f),
                                        offset = Offset(0f, 1f),
                                        blurRadius = 4f,
                                    ),
                                ),
                            )
                        }
                    },
                    actions = {
                        FilledTonalIconButton(
                            onClick = onOpenSearch,
                            modifier = Modifier.size(44.dp),
                        ) {
                            Icon(
                                imageVector = PhosphorIcons.Regular.MagnifyingGlass,
                                contentDescription = "Cari foto",
                                modifier = Modifier.size(22.dp),
                            )
                        }
                        Spacer(Modifier.size(4.dp))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = Color.Transparent,
                    ),
                    windowInsets = WindowInsets.statusBars,
                )
            },
        ) { sourceModifier ->
            MediaPermissionGate(modifier = Modifier.fillMaxSize()) {
                GalleryPagingContent(
                    items = items,
                    gridState = gridState,
                    contentPadding = gridContentPadding,
                    sourceModifier = sourceModifier,
                    onMediaClick = onMediaClick,
                )
            }
        }
    }
}

@Composable
private fun GalleryPagingContent(
    items: LazyPagingItems<MediaItem>,
    gridState: LazyGridState,
    contentPadding: PaddingValues,
    sourceModifier: Modifier,
    onMediaClick: (Long, Int) -> Unit,
) {
    val refresh = items.loadState.refresh
    when {
        refresh is LoadState.Loading && items.itemCount == 0 -> {
            LoadingState(contentPadding = contentPadding)
        }

        refresh is LoadState.Error && items.itemCount == 0 -> {
            ErrorState(
                contentPadding = contentPadding,
                message = refresh.error.localizedMessage
                    ?: "Terjadi kesalahan saat memuat galeri.",
                onRetry = { items.retry() },
            )
        }

        refresh is LoadState.NotLoading && items.itemCount == 0 -> {
            EmptyState(contentPadding = contentPadding)
        }

        else -> GalleryGrid(
            items = items,
            gridState = gridState,
            contentPadding = contentPadding,
            sourceModifier = sourceModifier,
            onMediaClick = onMediaClick,
        )
    }
}

@Composable
private fun GalleryGrid(
    items: LazyPagingItems<MediaItem>,
    gridState: LazyGridState,
    contentPadding: PaddingValues,
    sourceModifier: Modifier,
    onMediaClick: (Long, Int) -> Unit,
) {
    LazyVerticalGrid(
        state = gridState,
        columns = GridCells.Adaptive(minSize = 108.dp),
        modifier = Modifier
            .fillMaxSize()
            .then(sourceModifier),
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        items(items.itemCount) { index ->
            val item = items[index] ?: return@items
            AsyncImage(
                model = item.uri,
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .sharedPhotoElement(key = "photo-${item.id}")
                    .clickable { onMediaClick(item.id, index) },
            )
        }
    }
}

@Composable
private fun LoadingState(contentPadding: PaddingValues) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator()
    }
}

@Composable
private fun EmptyState(contentPadding: PaddingValues) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = PhosphorIcons.Regular.ImageSquare,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Belum ada foto",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Foto & video di perangkatmu akan muncul di sini.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ErrorState(
    contentPadding: PaddingValues,
    message: String,
    onRetry: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = PhosphorIcons.Regular.WarningCircle,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.error,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Gagal memuat",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) {
            Text("Coba lagi")
        }
    }
}

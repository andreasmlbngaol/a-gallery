package id.andreasmbngaol.agallery.domain.di

import id.andreasmbngaol.agallery.domain.usecase.GetAlbumsUseCase
import id.andreasmbngaol.agallery.domain.usecase.GetMediaPagingUseCase
import id.andreasmbngaol.agallery.domain.usecase.GetSettingsUseCase
import id.andreasmbngaol.agallery.domain.usecase.SetEdgeEffectModeUseCase
import id.andreasmbngaol.agallery.domain.usecase.ToggleFavoriteUseCase
import org.koin.dsl.module

val domainModule = module {
    factory { GetMediaPagingUseCase(get()) }
    factory { GetAlbumsUseCase(get()) }
    factory { ToggleFavoriteUseCase(get()) }
    factory { GetSettingsUseCase(get()) }
    factory { SetEdgeEffectModeUseCase(get()) }
}

package id.andreasmbngaol.agallery

import android.app.Application
import id.andreasmbngaol.agallery.core.di.appModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class AGalleryApp : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@AGalleryApp)
            modules(appModules)
        }
    }
}

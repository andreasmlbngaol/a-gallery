package id.andreasmbngaol.agallery.presentation.viewer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder
import id.andreasmbngaol.agallery.domain.model.MediaItem
import id.andreasmbngaol.agallery.domain.usecase.GetMediaPagingUseCase
import kotlinx.coroutines.flow.Flow

/**
 * Menyediakan aliran media untuk viewer, memakai sumber paging yang sama
 * dengan Gallery. Cache di-tempatkan di viewModelScope supaya rotate/config
 * change tidak trigger reload penuh.
 *
 * ## Catatan sort order
 *
 * Untuk sekarang viewer selalu pakai [GallerySortOrder.DateDesc]. Idealnya
 * viewer mengikuti sort order yang aktif di Gallery grid supaya urutan swipe
 * di viewer konsisten dengan urutan tampilan grid. Nanti bisa ditambahkan
 * dengan salah satu cara:
 *
 * 1. Pass `sortOrder` sebagai argumen `Screen.PhotoViewer` (nav args).
 * 2. Angkat state `sortOrder` ke repository / SharedFlow di level singleton
 *    lalu observe di kedua VM.
 *
 * Detail EXIF, aksi share/delete, dsb. akan ditambahkan menyusul.
 */
class PhotoViewerViewModel(
    getMediaPaging: GetMediaPagingUseCase,
) : ViewModel() {
    val media: Flow<PagingData<MediaItem>> =
        getMediaPaging(GallerySortOrder.DateDesc).cachedIn(viewModelScope)
}

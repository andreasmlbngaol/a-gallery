package id.andreasmbngaol.agallery.presentation.albums

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import id.andreasmbngaol.agallery.core.ui.GalleryTab
import id.andreasmbngaol.agallery.core.ui.GalleryTabScaffold
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder

/**
 * Layar Albums — daftar/grid album MediaStore.
 *
 * Untuk sekarang masih placeholder; strukturnya sudah dibungkus
 * [GalleryTabScaffold] supaya floating bar Gallery/Albums + Settings +
 * Sort terlihat di sini juga, dan tab "Albums" ter-highlight.
 *
 * [sortOrder] & [onToggleSort] di-forward supaya state sort persistent
 * saat user pindah Gallery ↔ Albums. Untuk sekarang albums belum ikut
 * pakai sortOrder, tapi tombolnya tetap terlihat konsisten dan siap
 * dipakai kalau nanti album di-sort.
 *
 * TODO: implementasi `GetAlbumsUseCase` + grid album.
 */
@Composable
fun AlbumsScreen(
    onSelectTab: (GalleryTab) -> Unit,
    onOpenSettings: () -> Unit,
    sortOrder: GallerySortOrder,
    onToggleSort: () -> Unit,
) {
    GalleryTabScaffold(
        selectedTab = GalleryTab.Albums,
        onSelectTab = onSelectTab,
        onOpenSettings = onOpenSettings,
        sortOrder = sortOrder,
        onToggleSort = onToggleSort,
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "Albums (belum diimplementasi)",
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

package id.andreasmbngaol.agallery.data.local.prefs

import kotlinx.serialization.Serializable

/**
 * Representasi tersimpan di DataStore. Sengaja dipisah dari domain [id.andreasmbngaol.agallery.domain.model.AppSettings]
 * supaya domain tetap bersih dari anotasi serialization & bebas dari perubahan
 * format storage. edgeEffectMode disimpan sebagai String nullable (null = default cerdas).
 */
@Serializable
data class AppSettingsDto(
    val edgeEffectMode: String? = null,
)

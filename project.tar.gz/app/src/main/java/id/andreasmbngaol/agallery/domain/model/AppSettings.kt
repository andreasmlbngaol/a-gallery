package id.andreasmbngaol.agallery.domain.model

/**
 * Preferensi aplikasi (domain).
 *
 * [edgeEffectMode] null = ikuti "default cerdas" (hybrid): FROSTED di API >= 32,
 * GRADIENT di bawahnya. Resolusi final butuh Build.VERSION, jadi dilakukan di
 * layer presentation; domain cukup menyimpan pilihan mentah user.
 */
data class AppSettings(
    val edgeEffectMode: EdgeEffectMode? = null,
)

package id.andreasmbngaol.agallery.core.navigation

import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import id.andreasmbngaol.agallery.core.ui.GalleryTab
import id.andreasmbngaol.agallery.domain.model.GallerySortOrder
import id.andreasmbngaol.agallery.presentation.albums.AlbumsScreen
import id.andreasmbngaol.agallery.presentation.animation.LocalSharedTransitionScope
import id.andreasmbngaol.agallery.presentation.gallery.GalleryGridScreen
import id.andreasmbngaol.agallery.presentation.settings.SettingsScreen
import id.andreasmbngaol.agallery.presentation.viewer.PhotoViewerScreen

/**
 * Host navigasi Nav3 untuk AGallery.
 *
 * ## Model tab (Gallery / Albums)
 *
 * Kedua screen root, [Screen.Gallery] dan [Screen.Albums], memakai
 * `GalleryTabScaffold` yang menampilkan floating bar bersama. Callback
 * `onSelectTab` di kedua screen diarahkan ke [handleTabSwitch] di sini,
 * yang **mengganti** top backstack (bukan push).
 *
 * Alasan replace, bukan push:
 * - Tab bukan hierarki navigasi berjenjang — dari sudut pandang user,
 *   Gallery dan Albums adalah dua pandangan setara dari root.
 * - Kalau push, back button akan bounce antara tab, yang aneh.
 * - Dengan replace, back dari root selalu keluar aplikasi (seperti perilaku
 *   Google Photos, iOS Photos).
 *
 * ## Sort state (hoisted)
 *
 * `sortOrder` di-hoist di level NavDisplay via [rememberSaveable] supaya:
 * - State tetap saat rotasi / process death.
 * - State tetap saat pindah Gallery ↔ Albums (kalau di dalam VM, VM Albums
 *   & Gallery adalah instance beda, statenya gak share).
 *
 * Screen Gallery meng-echo state ini ke VM via `LaunchedEffect(sortOrder) {
 * vm.setSortOrder(sortOrder) }` supaya PagingSource ikut refresh.
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun AGalleryNavDisplay() {
    val backStack = rememberNavBackStack(Screen.Gallery)

    // Sort state di level NavDisplay — lihat KDoc di atas. Enum disimpan
    // sebagai nama via Saver kustom (rememberSaveable default nggak bisa
    // handle enum langsung).
    var sortOrder by rememberSaveable(
        stateSaver = Saver<GallerySortOrder, String>(
            save = { it.name },
            restore = { GallerySortOrder.valueOf(it) },
        ),
    ) { mutableStateOf(GallerySortOrder.DateDesc) }

    val toggleSort: () -> Unit = {
        sortOrder = when (sortOrder) {
            GallerySortOrder.DateDesc -> GallerySortOrder.DateAsc
            GallerySortOrder.DateAsc -> GallerySortOrder.DateDesc
        }
    }

    // Ganti top backstack ke tab yang dipilih. No-op kalau sudah di tab itu.
    val handleTabSwitch: (GalleryTab) -> Unit = handler@{ tab ->
        val target: Screen = when (tab) {
            GalleryTab.Gallery -> Screen.Gallery
            GalleryTab.Albums -> Screen.Albums
        }
        if (backStack.lastOrNull() == target) return@handler
        backStack.removeLastOrNull()
        backStack.add(target)
    }

    // Catatan tipe: `backStack.add(Screen.Settings)` mengembalikan `Boolean`
    // (SnapshotStateList.add), sedangkan `onOpenSettings` di screen adalah
    // `() -> Unit`. Kalau ditulis satu-baris `val openSettings = {
    // backStack.add(Screen.Settings) }`, Kotlin akan meng-infer lambdanya
    // sebagai `() -> Boolean` — tidak kompatibel dengan `() -> Unit`.
    //
    // Dua cara memperbaikinya (dipilih opsi 1 karena tidak mengubah signature
    // publik screen):
    //   1. Deklarasi eksplisit `() -> Unit` + baris `Unit` di akhir body.
    //   2. Ubah semua `onOpenSettings` di screen jadi `() -> Boolean`.
    val openSettings: () -> Unit = {
        backStack.add(Screen.Settings)
        Unit
    }

    SharedTransitionLayout {
        CompositionLocalProvider(LocalSharedTransitionScope provides this) {
            NavDisplay(
                backStack = backStack,
                onBack = { backStack.removeLastOrNull() },
                entryProvider = { key ->
                    when (key) {
                        is Screen.Gallery -> NavEntry(key) {
                            GalleryGridScreen(
                                onMediaClick = { id, index ->
                                    backStack.add(
                                        Screen.PhotoViewer(
                                            mediaId = id,
                                            initialIndex = index,
                                        ),
                                    )
                                },
                                onSelectTab = handleTabSwitch,
                                onOpenSettings = openSettings,
                                sortOrder = sortOrder,
                                onToggleSort = toggleSort,
                                onOpenSearch = {
                                    // TODO: tambahkan Screen.Search + rute-nya.
                                },
                            )
                        }

                        is Screen.PhotoViewer -> NavEntry(key) {
                            PhotoViewerScreen(
                                mediaId = key.mediaId,
                                initialIndex = key.initialIndex,
                                onBack = { backStack.removeLastOrNull() },
                            )
                        }

                        is Screen.Albums -> NavEntry(key) {
                            AlbumsScreen(
                                onSelectTab = handleTabSwitch,
                                onOpenSettings = openSettings,
                                sortOrder = sortOrder,
                                onToggleSort = toggleSort,
                            )
                        }

                        is Screen.Settings -> NavEntry(key) { SettingsScreen() }

                        else -> NavEntry(key) { }
                    }
                },
            )
        }
    }
}

package id.andreasmbngaol.agallery.data.mapper

import id.andreasmbngaol.agallery.data.local.prefs.AppSettingsDto
import id.andreasmbngaol.agallery.domain.model.AppSettings
import id.andreasmbngaol.agallery.domain.model.EdgeEffectMode

fun AppSettingsDto.toDomain(): AppSettings =
    AppSettings(
        edgeEffectMode = edgeEffectMode?.let { raw ->
            EdgeEffectMode.entries.firstOrNull { it.name == raw }
        },
    )

fun AppSettings.toDto(): AppSettingsDto =
    AppSettingsDto(
        edgeEffectMode = edgeEffectMode?.name,
    )
